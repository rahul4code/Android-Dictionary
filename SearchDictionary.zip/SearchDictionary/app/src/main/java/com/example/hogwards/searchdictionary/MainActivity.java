public class MainActivity extends AppCompatActivity implements TextWatcher{
AutoCompleteTextView mAuto;
String mURL="http://techiesatish.com/demo_api/spinner.php";
Context mContext;
String TAG=MainActivity.class.getSimpleName();
String mName;
ArrayList<String> mCountryList;
ArrayAdapter mAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext=MainActivity.this;
        mCountryList=new ArrayList<>();
        mAuto=findViewById(R.id.auto_tv);
        mAdapter=new ArrayAdapter(mContext,android.R.layout.simple_dropdown_item_1line, mCountryList);
        mName=mAuto.getText().toString();
        mAuto.addTextChangedListener(this);
 
        loadData();
 
 
    }
 
    private void loadData() {
        RequestQueue requestQueue= Volley.newRequestQueue(mContext);
        StringRequest stringRequest=new StringRequest(Request.Method.GET, mURL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e(TAG, "onResponse: " +response);
                try{
                    JSONObject jsonObject=new JSONObject(response);
                    if(jsonObject.getInt("success")==1){
                        JSONArray jsonArray=jsonObject.getJSONArray("Name");
                        for(int i=0;i<jsonArray.length();i++){
                            JSONObject jsonObject1=jsonArray.getJSONObject(i);
                            Log.e(TAG, "onResponse: " +jsonObject1.getString("Country") );
                            mCountryList.add(jsonObject1.getString("Country"));
 
                        }
                        mAuto.setThreshold(1);
                        mAuto.setAdapter(mAdapter);
 
                    }
 
 
                }
 
                catch (JSONException e){e.printStackTrace();}
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        int socketTimeout = 30000;
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(policy);
        requestQueue.add(stringRequest);
    }
 
 
    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
 
    }
 
    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
    }
 
    @Override
    public void afterTextChanged(Editable editable) {
 
    }
}