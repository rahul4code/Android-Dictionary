package com.example.hogwards.searchdictionary;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;


public class DBManager extends SQLiteOpenHelper
{
    Context x;
    public DBManager(Context context)
    {
        super(context,"Dict",null,1);
        x=context;

    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        String q="create table Dictionary (Word text, Meaning text )";
        db.execSQL(q);
        Toast.makeText(x, "Table is Created", Toast.LENGTH_LONG).show();

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}