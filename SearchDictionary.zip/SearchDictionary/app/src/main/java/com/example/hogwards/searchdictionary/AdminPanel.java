package com.example.hogwards.searchdictionary;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AdminPanel extends AppCompatActivity {
    EditText adminuser,adminpass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_panel);
        adminuser=(EditText)findViewById(R.id.adminuser);
        adminpass=(EditText)findViewById(R.id.adminpass);

    }
    @Override
    public boolean onCreateOptionsMenu(Menu adminmenu)
    {
        getMenuInflater().inflate(R.menu.adminmenu,adminmenu);
        return  super.onCreateOptionsMenu(adminmenu);
    }
    @Override
    public  boolean onOptionsItemSelected(MenuItem item)
    {
        int id=item.getItemId();
        if(id==R.id.AdminLogout)
        {
            Intent LogoutIntent=new Intent(AdminPanel.this,MainActivity.class);
            startActivity(LogoutIntent);
            return  true;
        }
        if(id==R.id.ChangePassword)
        {
            Toast.makeText(this, "Not yet Created", Toast.LENGTH_LONG).show();

        }
        return super.onOptionsItemSelected(item);
    }
    public void LoginAdmin(View view)
    {
        String aaid,aapass;
        aaid=adminuser.getText().toString().trim();
        aapass=adminpass.getText().toString().trim();
        if(aaid.isEmpty())
        {
            adminuser.setError("Id is Empty");
            adminuser.requestFocus();
        }
        else if(aapass.isEmpty())
        {
            adminpass.setError("Password is Empty");
            adminpass.requestFocus();
        }
        else {
            if (aaid.equals("Admin") && aapass.equals("1234")) {
                Intent i = new Intent(this, Add_Word.class);
                startActivity(i);
            }
            else
            {
                Toast.makeText(this,"Invalid Credentials",Toast.LENGTH_LONG).show();
            }
        }
    }

}
