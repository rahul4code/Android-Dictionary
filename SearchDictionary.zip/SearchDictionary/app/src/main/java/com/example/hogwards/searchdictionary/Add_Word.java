package com.example.hogwards.searchdictionary;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Add_Word extends AppCompatActivity {
    EditText enterword,entermeaning;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add__word);
        enterword=(EditText)findViewById(R.id.enterword);
        entermeaning=(EditText)findViewById(R.id.entermeaning);
    }
    public void addword(View view)
    {
        String shabd,q,arth;
        shabd=enterword.getText().toString().trim();
        arth=entermeaning.getText().toString().trim();
        q="insert into Dictionary values('"+shabd+"','"+arth+"')";
        DBManager dm=new DBManager(this);
        SQLiteDatabase db=dm.getWritableDatabase();
        db.execSQL(q);
        Toast.makeText(this,"Word Added Successfully",Toast.LENGTH_LONG).show();
        enterword.setText("");
        entermeaning.setText("");

    }
    public void remove(View view)
    {
        String shbd;
        shbd=(enterword.getText().toString());
        DBManager dm=new DBManager(this);
        SQLiteDatabase db=dm.getWritableDatabase();
        String q2="select * from Dictionary where word='"+shbd+"'";
        String q3="delete from Dictionary where word='"+shbd+"'";
        Cursor c=db.rawQuery(q2,null);
        if(c.getCount()==0)
        {
            Toast.makeText(this, "Word is not Avaialable in Dictionary", Toast.LENGTH_LONG).show();
        }
        else
        {
            db.execSQL(q3);
            Toast.makeText(this, "Word removed Successfully", Toast.LENGTH_SHORT).show();
        }
    }
    public void Home(View View)
    {
        Intent i=new Intent(this,MainActivity.class);
        startActivity(i);
    }
}
