package com.example.hogwards.searchdictionary;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;


public abstract class DataManger extends SQLiteOpenHelper
{

    Context x;
    public DataManger(Context context)
    {
        super(context, "Dictin" ,null,1);
        x=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String q="Create Table Dict (Word Text,Meaning Teext";
        db.execSQL(q);
        Toast.makeText(x,"Table is Created",Toast.LENGTH_LONG).show();
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}